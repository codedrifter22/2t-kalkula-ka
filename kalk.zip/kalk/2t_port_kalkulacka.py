import streamlit as st
import math
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

# --- Konfigurácia stránky Streamlit ---
st.set_page_config(page_title="2T Motor Tuner", layout="wide", initial_sidebar_state="expanded")
st.title("🚀 2-Takt Motor - Pokročilá kalkulačka portov a návrh výfuku")

st.markdown("""
Táto aplikácia vám pomôže s návrhom a vizualizáciou kľúčových komponentov 2-taktného motora: prietokových portov a rezonančného výfuku.
Hoci ide o zjednodušené modely, poskytujú silný východiskový bod pre vaše ladenie.
""")

# --- Funkcie pre výpočty portov ---

def vypocitaj_objem_valca(vrtanie_mm, zdvih_mm):
    polomer = vrtanie_mm / 2
    objem_mm3 = math.pi * (polomer ** 2) * zdvih_mm
    objem_cm3 = objem_mm3 / 1000
    return round(objem_cm3, 2)

def vypocitaj_porty_v2(objem_cm3, otacky_rpm, zdvih_mm, vrtanie_mm, tvary_portov):
    """
    Vylepšená funkcia na výpočet parametrov portov s ohľadom na tvary.
    Používa empirické faktory, ktoré simulujú vplyv vplyv tvaru na efektivitu a prietok.
    """
    
    # Základné empirické odhady šírky a výšky ako percento vrtania/zdvihu
    # Tieto hodnoty sú upravené tak, aby boli zmysluplnejšie pre rôzne typy motorov
    
    # Výfuk (Exhaust) - najširší a najvyšší pre dobré vyplachovanie a výkon
    sirka_vyfuk_perc = 0.65  # 65% vrtania je bežná šírka
    vyska_vyfuk_perc = 0.33  # 33% zdvihu od TDC je typická výfuková výška
    
    # Preplachovacie (Transfer) - šírka závisí od počtu, výška od zdvihu
    sirka_preplach_perc = 0.35 # Pre jeden port, inak sa delí obvod
    vyska_preplach_perc = 0.23 # Nižšie ako výfuk
    
    # Sací (Intake) - ovplyvnený kľukou, menej kritický na absolútnu šírku
    sirka_saci_perc = 0.50 # Širší sací pre objem plnenia
    vyska_saci_perc = 0.20 # Krátky zdvih
    

    # Základné rozmery
    sirka_vyfuk = vrtanie_mm * sirka_vyfuk_perc
    vyska_vyfuk = zdvih_mm * vyska_vyfuk_perc
    
    sirka_hlavny = vrtanie_mm * sirka_preplach_perc
    vyska_hlavny = zdvih_mm * vyska_preplach_perc

    sirka_pomocny = sirka_hlavny * 0.7 # Menšie ako hlavné
    vyska_pomocny = vyska_hlavny * 0.8

    sirka_saci = vrtanie_mm * sirka_saci_perc
    vyska_saci = zdvih_mm * vyska_saci_perc
    

    # Korekcie pre tvary portov
    def apply_shape_correction(width, height, shape_type):
        if shape_type == "Obdĺžnik":
            return width, height
        elif shape_type == "Oblúk":
            # Oblúk môže mať mierne menšiu efektívnu plochu pre rovnakú nominálnu šírku,
            # ale znižuje opotrebenie krúžku. Zvýšime výšku pre kompenzáciu.
            return width * 0.95, height * 1.05
        elif shape_type == "Lichobežník":
            # Lichobežník môže mať lepší prietok pre rovnakú nominálnu plochu,
            # ale šírka je distribuovaná. Zväčšíme celkové rozmery.
            return width * 1.05, height * 1.02 # Zmeníme šírku
        return width, height # Default

    sirka_vyfuk, vyska_vyfuk = apply_shape_correction(sirka_vyfuk, vyska_vyfuk, tvary_portov["vyfuk"])
    sirka_hlavny, vyska_hlavny = apply_shape_correction(sirka_hlavny, vyska_hlavny, tvary_portov["hlavny"])
    sirka_pomocny, vyska_pomocny = apply_shape_correction(sirka_pomocny, vyska_pomocny, tvary_portov["pomocny"])
    sirka_saci, vyska_saci = apply_shape_correction(sirka_saci, vyska_saci, tvary_portov["saci"])

    # Ajustments based on RPM
    # Higher RPMs usually mean higher and wider ports for longer duration and more flow.
    # These are very rough adjustments.
    rpm_factor = otacky_rpm / 9000.0 # Base around 9000 RPM
    
    vyska_vyfuk *= (0.9 + 0.1 * rpm_factor) 
    vyska_hlavny *= (0.9 + 0.1 * rpm_factor)
    vyska_pomocny *= (0.9 + 0.1 * rpm_factor)

    sirka_vyfuk *= (0.9 + 0.1 * rpm_factor)
    sirka_hlavny *= (0.9 + 0.1 * rpm_factor)
    sirka_pomocny *= (0.9 + 0.1 * rpm_factor)
    
    # Ensure poz_vyfuk is top of port relative to TDC
    # For high RPM, port opens earlier (higher up from BDC), means smaller value for poz_vyfuk
    # For low RPM, port opens later (lower from BDC), means larger value for poz_vyfuk
    poz_vyfuk = zdvih_mm * 0.30 * (1.1 - 0.1 * rpm_factor) # Make it open earlier for higher RPM
    poz_hlavny = zdvih_mm * 0.65 * (1.1 - 0.1 * rpm_factor)
    poz_pomocny = zdvih_mm * 0.75 * (1.1 - 0.1 * rpm_factor)
    poz_saci = zdvih_mm * 0.85 * (1.1 - 0.1 * rpm_factor)


    return {
        "vyfuk": {"sirka": sirka_vyfuk, "vyska": vyska_vyfuk, "pozicia_od_tdc": poz_vyfuk, "tvar": tvary_portov["vyfuk"]},
        "hlavny": {"sirka": sirka_hlavny, "vyska": vyska_hlavny, "pozicia_od_tdc": poz_hlavny, "tvar": tvary_portov["hlavny"]},
        "pomocny": {"sirka": sirka_pomocny, "vyska": vyska_pomocny, "pozicia_od_tdc": poz_pomocny, "tvar": tvary_portov["pomocny"]},
        "saci": {"sirka": sirka_saci, "vyska": vyska_saci, "pozicia_od_tdc": poz_saci, "tvar": tvary_portov["saci"]}
    }

def plocha_portu(sirka_mm, vyska_mm, tvar="Obdĺžnik"):
    # Presnejšie aproximácie plôch
    if tvar == "Oblúk":
        # Približná plocha oblúkového portu je ako obdĺžnik s oblúkom na vrchu
        # Použijeme korekciu 0.85 pre celkovú plochu
        return round(sirka_mm * vyska_mm * 0.85, 2)
    elif tvar == "Lichobežník":
        # Predpokladajme zúženie na 70% na spodnej strane pre lichobežník
        sirka_horna = sirka_mm
        sirka_dolna = sirka_mm * 0.7 
        return round(((sirka_horna + sirka_dolna) / 2) * vyska_mm, 2)
    else: # Obdĺžnik
        return round(sirka_mm * vyska_mm, 2)

def calculate_crank_angle_from_tdc(piston_pos_from_tdc_mm, zdvih_mm):
    # Tento vzorec je presnejší, zohľadňuje dĺžku ojnice.
    # Pre jednoduchosť to udržím zjednodušené ako predtým,
    # ak neposkytnete dĺžku ojnice.
    if zdvih_mm == 0: return 0.0
    
    # Piest je na TDC pri y=zdvih, na BDC pri y=0 (pre naše grafy)
    # y = zdvih - piston_pos_from_tdc_mm (Y-súradnica piesta od BDC)
    
    # Pozícia hornej hrany portu od TDC je 'pos_from_tdc_mm'
    # Ak piest je na pozícii `pos_from_tdc_mm` od TDC, aký je uhol kľuky?
    
    # Vzťah polohy piesta a uhla kľuky (zjednodušený)
    # y_rel = (zdvih/2) * (1 - cos(theta))
    # cos(theta) = 1 - (2*y_rel / zdvih)
    
    # y_rel je vzdialenosť piesta od TDC.
    y_rel = piston_pos_from_tdc_mm 
    
    # Zabezpečenie, aby arccos dostal hodnotu medzi -1 a 1
    cos_val = 1 - (2 * y_rel / zdvih_mm)
    cos_val = max(min(cos_val, 1.0), -1.0) 
    
    angle_rad = math.acos(cos_val)
    return math.degrees(angle_rad)

def get_port_timing_details(port_pozicia_horna_hrana_od_tdc_mm, port_vyska_mm, zdvih_mm):
    if zdvih_mm == 0:
        return 0.0, 0.0, 0.0

    # Uhol, pri ktorom piest odkryje HORNÚ HRANU portu.
    # Toto je bod otvorenia/zatvorenia portu.
    angle_at_port_edge_deg = calculate_crank_angle_from_tdc(port_pozicia_horna_hrana_od_tdc_mm, zdvih_mm)
    
    # Doba trvania otvorenia portu (v stupňoch kľukového hriadeľa)
    # Port je otvorený symetricky okolo BDC (180 stupňov).
    # Trvanie = 2 * (180 - uhol otvorenia)
    duration_deg = round(2 * (180 - angle_at_port_edge_deg), 2)
    
    # Bod otvorenia portu: Pred BDC
    # Piesta prechádza cez TDC (0), potom klesá.
    # Otvorí sa, keď dosiahne uhol pred 180 stupňov.
    open_point_deg_ATDC = round(180 - angle_at_port_edge_deg, 2)
    
    # Bod zatvorenia portu: Po BDC
    # Piesta stúpa naspäť k TDC.
    # Zatvorí sa, keď dosiahne uhol po 180 stupňov.
    close_point_deg_ABDC = round(180 + angle_at_port_edge_deg, 2)

    return max(0, duration_deg), max(0, open_point_deg_ATDC), max(0, close_point_deg_ABDC)

def cas_otvorenia_ms(angle_deg, rpm):
    if rpm == 0:
        return 0.0
    return round((angle_deg / 360) * (60 / rpm) * 1000, 2) 

# --- Funkcie pre vizualizáciu portov ---

def draw_ports_unrolled(ports_data, vrtanie, zdvih, num_main_transfers, num_aux_transfers, show_vertical_lines, piston_pos_mm):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8), facecolor='#000040', gridspec_kw={'width_ratios': [3, 1]})
    ax1.set_facecolor('#000040') 
    ax2.set_facecolor('#000040') 

    for ax in [ax1, ax2]:
        ax.tick_params(axis='x', colors='white')
        ax.tick_params(axis='y', colors='white')
        ax.xaxis.label.set_color('white')
        ax.yaxis.label.set_color('white')
        ax.title.set_color('white')

    circumference = math.pi * vrtanie 
    
    # Cylinder outlines
    ax1.plot([-circumference/2, circumference/2], [0, 0], color='lime', linewidth=1.5, zorder=2) # BDC line
    ax1.plot([-circumference/2, circumference/2], [zdvih, zdvih], color='yellow', linewidth=1.5, zorder=2) # TDC line
    ax1.plot([-circumference/2, -circumference/2], [0, zdvih], color='lightgray', linewidth=1.5, zorder=2) # Left wall
    ax1.plot([circumference/2, circumference/2], [0, zdvih], color='lightgray', linewidth=1.5, zorder=2) # Right wall

    ax1.text(-circumference/2 + 2, 1, "BDC (0mm)", verticalalignment='bottom', horizontalalignment='left', color='lime', fontsize=12, weight='bold')
    ax1.text(-circumference/2 + 2, zdvih - 1, f"TDC ({zdvih}mm)", verticalalignment='top', horizontalalignment='left', color='yellow', fontsize=12, weight='bold')

    port_colors = {
        "vyfuk": "red",         
        "hlavny": "lime",      
        "pomocny": "lightgreen",
        "saci": "magenta"       
    }
    
    port_drawing_config = []
    
    port_drawing_config.append({
        "type": "vyfuk",
        "data": ports_data["vyfuk"],
        "x_center": 0, 
        "label": "Výfuk"
    })
    
    port_drawing_config.append({
        "type": "saci",
        "data": ports_data["saci"],
        "x_center": 0, 
        "label": "Sací"
    })

    # Rozdelenie preplachovacích portov rovnomerne po obvode
    # Dynamic positioning for main transfers
    main_offsets = []
    if num_main_transfers == 1:
        main_offsets = [0] # If only one, center it
    elif num_main_transfers == 2:
        main_offsets = [-vrtanie * 0.2, vrtanie * 0.2]
    elif num_main_transfers == 3:
        main_offsets = [-vrtanie * 0.25, 0, vrtanie * 0.25]
    elif num_main_transfers == 4:
        main_offsets = [-vrtanie * 0.35, -vrtanie * 0.1, vrtanie * 0.1, vrtanie * 0.35]
    
    for i, offset in enumerate(main_offsets):
        port_drawing_config.append({
            "type": "hlavny",
            "data": ports_data["hlavny"],
            "x_center": offset,
            "label": f"Hlavný {i+1}"
        })

    # Dynamic positioning for auxiliary transfers
    aux_offsets = []
    if num_aux_transfers == 1:
        aux_offsets = [0]
    elif num_aux_transfers == 2:
        aux_offsets = [-vrtanie * 0.3, vrtanie * 0.3]
    elif num_aux_transfers == 3:
        aux_offsets = [-vrtanie * 0.4, 0, vrtanie * 0.4]
    elif num_aux_transfers == 4:
        aux_offsets = [-vrtanie * 0.45, -vrtanie * 0.2, vrtanie * 0.2, vrtanie * 0.45]

    for i, offset in enumerate(aux_offsets):
        # Adjust auxiliary port positions to avoid overlap with main ports if they are close
        overlap_threshold = 5 # mm
        adjusted_offset = offset
        for main_offset in main_offsets:
            if abs(adjusted_offset - main_offset) < overlap_threshold:
                adjusted_offset += np.sign(adjusted_offset - main_offset) * overlap_threshold if adjusted_offset != main_offset else overlap_threshold
        
        port_drawing_config.append({
            "type": "pomocny",
            "data": ports_data["pomocny"],
            "x_center": adjusted_offset,
            "label": f"Pomocný {i+1}"
        })
    
    timing_data = []

    # Drawing and labeling ports
    for port_info in port_drawing_config:
        port_type = port_info["type"]
        width = port_info["data"]["sirka"]
        height = port_info["data"]["vyska"]
        pos_from_tdc = port_info["data"]["pozicia_od_tdc"] 
        tvar = port_info["data"]["tvar"]
        x_center = port_info["x_center"]
        label = port_info["label"]
        color = port_colors[port_type] 

        y_top_of_port_from_bdc = zdvih - pos_from_tdc
        y_bottom_of_port_from_bdc = y_top_of_port_from_bdc - height 

        x_left = x_center - (width / 2)

        piston_current_y_from_bdc = zdvih - piston_pos_mm
        is_open = (piston_current_y_from_bdc >= y_bottom_of_port_from_bdc) and \
                  (piston_current_y_from_bdc <= y_top_of_port_from_bdc) 


        if tvar == "Obdĺžnik":
            rect = patches.Rectangle((x_left, y_bottom_of_port_from_bdc), width, height, 
                                     linewidth=1.5, edgecolor=color, 
                                     facecolor=color, alpha=0.9 if is_open else 0.2, zorder=3)
            ax1.add_patch(rect)
        elif tvar == "Oblúk":
            rect_height_base = height * 0.6
            arc_height_portion = height * 0.4
            rect = patches.Rectangle((x_left, y_bottom_of_port_from_bdc), width, rect_height_base,
                                     linewidth=1.5, edgecolor=color,
                                     facecolor=color, alpha=0.9 if is_open else 0.2, zorder=3)
            ax1.add_patch(rect)
            arc_center_x = x_center
            arc_bottom_y_coord = y_bottom_of_port_from_bdc + rect_height_base
            arc_patch = patches.Arc((arc_center_x, arc_bottom_y_coord), width, arc_height_portion * 2,
                                    theta1=0, theta2=180, linewidth=1.5, edgecolor=color, 
                                    facecolor=color, alpha=0.9 if is_open else 0.2, zorder=3)
            ax1.add_patch(arc_patch)
        elif tvar == "Lichobežník":
            top_width = width 
            bottom_width = width * 0.7 
            points = [
                (x_center - bottom_width / 2, y_bottom_of_port_from_bdc), 
                (x_center + bottom_width / 2, y_bottom_of_port_from_bdc), 
                (x_center + top_width / 2, y_bottom_of_port_from_bdc + height), 
                (x_center - top_width / 2, y_bottom_of_port_from_bdc + height)  
            ]
            polygon = patches.Polygon(points, linewidth=1.5, edgecolor=color,
                                      facecolor=color, alpha=0.9 if is_open else 0.2, zorder=3)
            ax1.add_patch(polygon)
            
        text_x = x_center
        
        # Improved text positioning to avoid overlaps
        # Calculate ideal y positions for labels
        label_y_ideal = y_bottom_of_port_from_bdc + height + 3
        tdc_y_ideal = y_top_of_port_from_bdc - 2 # Inside the port, closer to top edge
        dims_y_ideal = y_bottom_of_port_from_bdc + 2 # Inside the port, closer to bottom edge

        # Simple overlap prevention for demonstration (more robust methods exist)
        if port_type == "vyfuk": # Exhaust is typically the highest, so its labels can be higher
            label_y_offset = 0
            tdc_y_offset = 0
            dims_y_offset = 0
        elif port_type == "hlavny":
            label_y_offset = 5
            tdc_y_offset = 5
            dims_y_offset = 5
        elif port_type == "pomocny":
            label_y_offset = 10
            tdc_y_offset = 10
            dims_y_offset = 10
        elif port_type == "saci": # Intake is typically lowest
            label_y_offset = -5
            tdc_y_offset = -5
            dims_y_offset = -5


        ax1.text(text_x, label_y_ideal + label_y_offset, label,
                color='white', fontsize=10, ha='center', va='bottom', 
                bbox=dict(facecolor='black', alpha=0.6, edgecolor='none', boxstyle='round,pad=0.2'), zorder=4)
        
        ax1.text(text_x, tdc_y_ideal + tdc_y_offset, 
                f"TDC: {pos_from_tdc:.1f}mm", color='yellow', fontsize=8, ha='center', va='top', 
                bbox=dict(facecolor='black', alpha=0.4, edgecolor='none', boxstyle='round,pad=0.2'), zorder=4)
        
        ax1.text(text_x, dims_y_ideal + dims_y_offset, 
                f"{width:.1f}x{height:.1f}mm", color='cyan', fontsize=8, ha='center', va='bottom', 
                bbox=dict(facecolor='black', alpha=0.4, edgecolor='none', boxstyle='round,pad=0.2'), zorder=4)

        if show_vertical_lines:
            ax1.plot([x_center, x_center], 
                     [y_bottom_of_port_from_bdc, y_top_of_port_from_bdc], 
                     color='gray', linestyle=':', linewidth=0.5, zorder=1)

        duration_deg, open_point_deg_ATDC, close_point_deg_ABDC = get_port_timing_details(pos_from_tdc, height, zdvih)
        timing_data.append({
            "label": label,
            "y_start_mm_from_bdc": y_bottom_of_port_from_bdc, 
            "y_end_mm_from_bdc": y_top_of_port_from_bdc,             
            "duration_deg": duration_deg,
            "open_point_deg_ATDC": open_point_deg_ATDC,
            "close_point_deg_ABDC": close_point_deg_ABDC,
            "color": color
        })

    # Piston line and fill
    piston_y_from_bdc = zdvih - piston_pos_mm 
    ax1.axhline(y=piston_y_from_bdc, color='orange', linestyle='--', linewidth=2, zorder=6, label="Pozícia piesta")
    ax1.text(circumference/2 + 5, piston_y_from_bdc, "Piest", color='orange', fontsize=12, va='center')
    ax1.fill_between([-circumference/2, circumference/2], 0, piston_y_from_bdc, color='darkgray', alpha=0.3, zorder=5) 
    
    ax1.set_xlim(-circumference/2 - 20, circumference/2 + 20) 
    ax1.set_ylim(-10, zdvih + 25) 
    
    ax1.set_xlabel("Rozvinutý obvod valca (mm)", color='white')
    ax1.set_ylabel("Výška od BDC (mm)", color='white')
    ax1.set_title("Rozloženie portov na rozvinutom valci", color='white', fontsize=14)
    ax1.set_aspect('auto', adjustable='box') 
    
    y_major_tick_interval = 5
    x_major_tick_interval = 5 
    ax1.set_yticks(np.arange(0, zdvih + y_major_tick_interval, y_major_tick_interval))
    ax1.set_xticks(np.arange(math.floor(-circumference/2 / x_major_tick_interval) * x_major_tick_interval, 
                             math.ceil(circumference/2 / x_major_tick_interval) * x_major_tick_interval + 1, 
                             x_major_tick_interval))
    ax1.grid(True, which='major', color='gray', linestyle=':', linewidth=0.5, alpha=0.5, zorder=0)
    ax1.yaxis.set_label_position("left")
    ax1.yaxis.tick_left()
    
    # Timing Chart (ax2)
    ax2.set_title("Časovanie otvorenia portov", color='white', fontsize=14)
    ax2.set_xlabel("Port", color='white')
    ax2.set_ylabel("Výška od BDC (mm)", color='white')
    ax2.set_ylim(-10, zdvih + 25) 
    ax2.set_xlim(-0.5, len(timing_data) - 0.5) 

    ax2.axhline(y=0, color='lime', linestyle='-', linewidth=2, zorder=2) 
    ax2.axhline(y=zdvih, color='yellow', linestyle='-', linewidth=2, zorder=2) 
    ax2.text(-0.4, 1, "BDC (0mm)", verticalalignment='bottom', horizontalalignment='left', color='lime', fontsize=12, weight='bold')
    ax2.text(-0.4, zdvih - 1, f"TDC ({zdvih}mm)", verticalalignment='top', horizontalalignment='left', color='yellow', fontsize=12, weight='bold')

    timing_data_sorted = sorted(timing_data, key=lambda x: x['y_end_mm_from_bdc'], reverse=True) 

    port_names_for_ticks = []
    
    ax2_deg = ax2.twinx()
    ax2_deg.set_ylabel("Uhol kľukového hriadeľa (°) od TDC", color='white')
    ax2_deg.tick_params(axis='y', colors='white')
    ax2_deg.set_ylim(-10, zdvih + 25) 
    
    y_tick_mm = np.linspace(0, zdvih, 7) 
    degree_ticks = [round(calculate_crank_angle_from_tdc(zdvih - y, zdvih), 0) for y in y_tick_mm]
    ax2_deg.set_yticks(y_tick_mm)
    ax2_deg.set_yticklabels([f"{d:.0f}°" for d in degree_ticks]) 

    for i, port in enumerate(timing_data_sorted):
        y_bottom_bar = port["y_start_mm_from_bdc"] 
        y_top_bar = port["y_end_mm_from_bdc"]

        ax2.bar(i, height=(y_top_bar - y_bottom_bar), 
                bottom=y_bottom_bar, 
                width=0.8, 
                color=port["color"], alpha=0.7, zorder=3)
        
        ax2.text(i, y_bottom_bar - 2, 
                 f"OP: {port['open_point_deg_ATDC']:.0f}° ATDC", 
                 ha='center', va='top', color='yellow', fontsize=7, zorder=4)
        ax2.text(i, y_top_bar + 2, 
                 f"Duration: {port['duration_deg']:.0f}°", 
                 ha='center', va='bottom', color='cyan', fontsize=7, zorder=4)
        
        port_names_for_ticks.append(port["label"])

    ax2.set_xticks(np.arange(len(port_names_for_ticks)))
    ax2.set_xticklabels(port_names_for_ticks, rotation=45, ha='right', color='white', fontsize=10)
    ax2.grid(True, which='major', color='gray', linestyle=':', linewidth=0.5, alpha=0.5, zorder=0)

    plt.tight_layout() 
    st.pyplot(fig)


def draw_engine_cutaway(ports_data, vrtanie, zdvih, piston_pos_mm, num_main_transfers, num_aux_transfers):
    fig, ax = plt.subplots(figsize=(6, 9), facecolor='#000040')
    ax.set_facecolor('#000040') 

    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')
    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')
    ax.title.set_color('white')

    cylinder_width = vrtanie
    cylinder_x_left = -cylinder_width / 2
    cylinder_x_right = cylinder_width / 2
    
    # Cylinder walls
    ax.plot([cylinder_x_left - 5, cylinder_x_left - 5], [0, zdvih + 10], color='gray', linewidth=4, solid_capstyle='round', zorder=1)
    ax.plot([cylinder_x_right + 5, cylinder_x_right + 5], [0, zdvih + 10], color='gray', linewidth=4, solid_capstyle='round', zorder=1)

    ax.plot([cylinder_x_left, cylinder_x_left], [0, zdvih], color='lightgray', linewidth=1, zorder=1)
    ax.plot([cylinder_x_right, cylinder_x_right], [0, zdvih], color='lightgray', linewidth=1, zorder=1)

    # BDC and TDC lines
    ax.axhline(y=0, color='lime', linestyle='-', linewidth=2, zorder=2)
    ax.text(cylinder_x_left - 10, 0, "BDC", verticalalignment='center', horizontalalignment='right', color='lime', fontsize=10, weight='bold')
    
    ax.axhline(y=zdvih, color='yellow', linestyle='-', linewidth=2, zorder=2)
    ax.text(cylinder_x_left - 10, zdvih, "TDC", verticalalignment='center', horizontalalignment='right', color='yellow', fontsize=10, weight='bold')

    # Piston
    piston_y_bottom = zdvih - piston_pos_mm # Current Y position of the bottom of the piston from BDC
    piston_height_vis = 0.1 * zdvih # Visual height of the piston for drawing
    
    piston_rect = patches.Rectangle(
        (cylinder_x_left, piston_y_bottom - piston_height_vis/2), # Piston is drawn slightly above its "position" to show its volume
        cylinder_width, 
        piston_height_vis,  
        facecolor='orange', edgecolor='darkorange', linewidth=1.5, zorder=5
    )
    ax.add_patch(piston_rect)

    # Connecting rod and crankshaft (simplified)
    crank_center_y = -zdvih / 2 
    ax.plot([0, 0], [piston_y_bottom - piston_height_vis/2, crank_center_y], color='brown', linewidth=3, zorder=4) # Connecting rod
    ax.plot(0, crank_center_y, 'o', color='darkred', markersize=10, zorder=7) # Crankshaft center

    # Combustion chamber
    combustion_chamber_height = 0.1 * zdvih 
    ax.add_patch(patches.Rectangle(
        (cylinder_x_left, zdvih), 
        cylinder_width, 
        combustion_chamber_height, 
        facecolor='darkgray', edgecolor='lightgray', linewidth=1, zorder=0
    ))
    ax.plot(0, zdvih + combustion_chamber_height + 2, '^', color='white', markersize=8, zorder=8) # Spark plug indication

    port_colors = {
        "vyfuk": "red",         
        "hlavny": "lime",      
        "pomocny": "lightgreen",
        "saci": "magenta"       
    }

    port_names = {
        "vyfuk": "Výfuk",
        "saci": "Sací",
        "hlavny": "Preplach", 
        "pomocny": "Pomocný Preplach" 
    }

    def draw_port_shape_with_flow(ax_obj, x_left, y_top_from_bdc, width, height, color, tvar, alpha, flow_direction=None, label_x_offset=0):
        # Calculate y_bottom from y_top and height
        y_bottom_from_bdc = y_top_from_bdc - height

        # Draw the port shape
        if tvar == "Obdĺžnik":
            rect = patches.Rectangle((x_left, y_bottom_from_bdc), width, height, 
                                     linewidth=0.5, edgecolor='black', 
                                     facecolor=color, alpha=alpha, zorder=3)
            ax_obj.add_patch(rect)
        elif tvar == "Oblúk":
            rect_height_base = height * 0.6
            arc_height_portion = height * 0.4
            rect = patches.Rectangle((x_left, y_bottom_from_bdc), width, rect_height_base,
                                     linewidth=0.5, edgecolor='black',
                                     facecolor=color, alpha=alpha, zorder=3)
            ax_obj.add_patch(rect)
            arc_center_x = x_left + width / 2
            arc_bottom_y_coord = y_bottom_from_bdc + rect_height_base
            arc_patch = patches.Arc((arc_center_x, arc_bottom_y_coord), width, arc_height_portion * 2,
                                    theta1=0, theta2=180, linewidth=0.5, edgecolor='black', 
                                    facecolor=color, alpha=alpha, zorder=3)
            ax_obj.add_patch(arc_patch)
        elif tvar == "Lichobežník":
            top_width = width 
            bottom_width = width * 0.7 
            
            x_center = x_left + width / 2
            points_trap = [
                (x_center - bottom_width / 2, y_bottom_from_bdc), 
                (x_center + bottom_width / 2, y_bottom_from_bdc), 
                (x_center + top_width / 2, y_top_from_bdc), 
                (x_center - top_width / 2, y_top_from_bdc)  
            ]
            polygon = patches.Polygon(points_trap, linewidth=0.5, edgecolor='black',
                                      facecolor=color, alpha=alpha, zorder=3)
            ax_obj.add_patch(polygon)


        # Draw flow arrows if specified and port is "open" (alpha > 0.5)
        if flow_direction and alpha > 0.5:
            arrow_color = 'cyan' if 'in' in flow_direction else 'orange'
            arrow_y = y_bottom_from_bdc + height / 2
            arrow_length = 0.1 * vrtanie # Relative to bore
            
            if flow_direction == 'out_left': # Exhaust
                ax_obj.arrow(x_left - 5, arrow_y, -arrow_length, 0, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)
            elif flow_direction == 'out_right': # Exhaust
                 ax_obj.arrow(x_left + width + 5, arrow_y, arrow_length, 0, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)
            elif flow_direction == 'in_left': # Transfer/Scavenging
                ax_obj.arrow(x_left - 5, arrow_y, arrow_length, 0, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)
            elif flow_direction == 'in_right': # Transfer/Scavenging
                ax_obj.arrow(x_left + width + 5, arrow_y, -arrow_length, 0, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)
            elif flow_direction == 'saci_down': # Intake
                 ax_obj.arrow(x_left + width/2, y_bottom_from_bdc - 5, 0, -arrow_length, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)
            elif flow_direction == 'saci_up': # Intake (reverse flow)
                 ax_obj.arrow(x_left + width/2, y_top_from_bdc + 5, 0, arrow_length, 
                             head_width=3, head_length=5, fc=arrow_color, ec=arrow_color, zorder=9)

    # Exhaust Port
    exh = st.session_state.porty["vyfuk"] 
    exh_y_top_from_tdc = exh["pozicia_od_tdc"]
    exh_y_top_from_bdc = zdvih - exh_y_top_from_tdc
    exh_y_bottom_from_bdc = exh_y_top_from_bdc - exh["vyska"]

    exh_is_open = piston_y_bottom >= exh_y_bottom_from_bdc and piston_y_bottom <= exh_y_top_from_bdc
    
    draw_port_shape_with_flow(ax, -exh["sirka"]/2, exh_y_top_from_bdc, exh["sirka"], exh["vyska"], 
                    port_colors["vyfuk"], exh["tvar"], 1.0 if exh_is_open else 0.2, 
                    'out_left' if exh_is_open else None) 
    ax.text(-exh["sirka"]/2 - 5, exh_y_top_from_bdc - exh["vyska"]/2, port_names["vyfuk"],
            color='white', fontsize=9, ha='right', va='center')


    # Intake Port (Sací) - usually opposite to exhaust
    saci = st.session_state.porty["saci"] 
    saci_y_top_from_tdc = saci["pozicia_od_tdc"]
    saci_y_top_from_bdc = zdvih - saci_y_top_from_tdc
    saci_y_bottom_from_bdc = saci_y_top_from_tdc - saci["vyska"]

    saci_is_open = piston_y_bottom >= saci_y_bottom_from_bdc and piston_y_bottom <= saci_y_top_from_bdc
    
    draw_port_shape_with_flow(ax, -saci["sirka"]/2, saci_y_top_from_bdc, saci["sirka"], saci["vyska"],
                    port_colors["saci"], saci["tvar"], 1.0 if saci_is_open else 0.2,
                    'saci_down' if saci_is_open else None) 
    ax.text(-saci["sirka"]/2 - 5, saci_y_top_from_bdc - saci["vyska"]/2, port_names["saci"],
            color='white', fontsize=9, ha='right', va='center')


    # Main Transfer Ports (2 are usually on the sides)
    main_transfer = st.session_state.porty["hlavny"]
    main_y_top_from_tdc = main_transfer["pozicia_od_tdc"]
    main_y_top_from_bdc = zdvih - main_y_top_from_tdc
    main_y_bottom_from_bdc = main_y_top_from_bdc - main_transfer["vyska"]

    main_is_open = piston_y_bottom >= main_y_bottom_from_bdc and piston_y_bottom <= main_y_top_from_bdc
    
    if num_main_transfers >= 1:
        draw_port_shape_with_flow(ax, cylinder_x_left, main_y_top_from_bdc, main_transfer["sirka"], main_transfer["vyska"],
                        port_colors["hlavny"], main_transfer["tvar"], 1.0 if main_is_open else 0.2,
                        'in_right' if main_is_open else None) 
        ax.text(cylinder_x_left - 5, main_y_top_from_bdc - main_transfer["vyska"]/2, f"{port_names['hlavny']} 1",
                color='white', fontsize=9, ha='right', va='center')

    if num_main_transfers >= 2:
        draw_port_shape_with_flow(ax, cylinder_x_right - main_transfer["sirka"], main_y_top_from_bdc, main_transfer["sirka"], main_transfer["vyska"],
                        port_colors["hlavny"], main_transfer["tvar"], 1.0 if main_is_open else 0.2,
                        'in_left' if main_is_open else None) 
        ax.text(cylinder_x_right + 5, main_y_top_from_bdc - main_transfer["vyska"]/2, f"{port_names['hlavny']} 2",
                color='white', fontsize=9, ha='left', va='center')
    
    # Auxiliary Transfer Ports
    aux_transfer = st.session_state.porty["pomocny"]
    aux_y_top_from_tdc = aux_transfer["pozicia_od_tdc"]
    aux_y_top_from_bdc = zdvih - aux_y_top_from_tdc
    aux_y_bottom_from_bdc = aux_y_top_from_tdc - aux_transfer["vyska"]

    aux_is_open = piston_y_bottom >= aux_y_bottom_from_bdc and piston_y_bottom <= aux_y_top_from_bdc

    # For simplicity, if main transfers exist, place aux slightly offset
    # This is a very simplified assumption for side-view cutaway
    offset_from_main = main_transfer["sirka"] * 0.7 if num_main_transfers > 0 else 0
    
    if num_aux_transfers >= 1:
        draw_port_shape_with_flow(ax, cylinder_x_left + offset_from_main, aux_y_top_from_bdc, aux_transfer["sirka"], aux_transfer["vyska"],
                        port_colors["pomocny"], aux_transfer["tvar"], 1.0 if aux_is_open else 0.2,
                        'in_right' if aux_is_open else None) 
        ax.text(cylinder_x_left - 10, aux_y_top_from_bdc - aux_transfer["vyska"]/2, f"{port_names['pomocny']} 1",
                color='white', fontsize=9, ha='right', va='center')
    if num_aux_transfers >= 2:
        draw_port_shape_with_flow(ax, cylinder_x_right - aux_transfer["sirka"] - offset_from_main, aux_y_top_from_bdc, aux_transfer["sirka"], aux_transfer["vyska"],
                        port_colors["pomocny"], aux_transfer["tvar"], 1.0 if aux_is_open else 0.2,
                        'in_left' if aux_is_open else None) 
        ax.text(cylinder_x_right + 10, aux_y_top_from_bdc - aux_transfer["vyska"]/2, f"{port_names['pomocny']} 2",
                color='white', fontsize=9, ha='left', va='center')


    ax.set_xlim(-vrtanie * 0.8, vrtanie * 0.8) 
    ax.set_ylim(-zdvih / 4, zdvih * 1.2 + combustion_chamber_height) 
    
    ax.set_xlabel("Priečny rez (mm)", color='white')
    ax.set_ylabel("Výška od BDC (mm)", color='white')
    ax.set_title("Simulácia rezu motora", color='white', fontsize=14)
    ax.set_aspect('equal', adjustable='box') 
    ax.grid(True, which='major', color='gray', linestyle=':', linewidth=0.5, alpha=0.5, zorder=0)

    plt.tight_layout()
    st.pyplot(fig)


def navrh_vyfuku(otacky_vykonu_rpm, teplota_vyfuku_c, vrtanie_mm, objem_motora_cm3, vyfuk_duration_deg, vyfuk_sirka_mm):
    
    # Konštanty a prevody
    R = 287.05 # plynová konštanta pre vzduch (J/kg·K)
    k = 1.4    # adibatický exponent pre vzduch
    M_exhaust_kg_per_mol = 0.029 # kg/mol (približná molárna hmotnosť spalín)

    # Rýchlosť zvuku vo výfukových plynoch (m/s)
    teplota_k = teplota_vyfuku_c + 273.15
    rychlost_zvuku_ms = math.sqrt(k * (R / M_exhaust_kg_per_mol) * teplota_k)
    Vs_mm_s = rychlost_zvuku_ms * 1000

    # Počiatočný priemer výfukového kolena (D1)
    Dp = vyfuk_sirka_mm
    D1 = Dp * 1.2 # mm, Priemer vstupu do expanznej komory
    D1 = max(15.0, D1) # Minimum 15mm
    
    # Koncový priemer stredného valca (D4 - najväčší priemer)
    # Zohľadňujeme aj objem motora
    D4_from_bore = vrtanie_mm * 1.5 
    D4_from_volume = math.pow((objem_motora_cm3 * 1000 * 2 / math.pi), 1/3) # Zjednodušený vzorec, aby bol realistickejší
    D4 = max(D4_from_bore, D4_from_volume * 0.8) # Vezmeme väčší z nich, s korekciou pre objem
    D4 = min(D4, 3.0 * Dp) 
    D4 = max(40.0, D4) # Minimum 40mm
    
    # Priemer koncovej trubky (Stinger) D5
    D5 = Dp * 0.6 # mm
    D5 = max(10.0, D5) # Minimum 10mm
    
    # Dĺžky sekcií - zjednodušené pravidlá
    # L1: Typicky 1.5 až 2.0 násobok vrtania + fixná hodnota
    L1 = vrtanie_mm * 1.8 + 50 
    L1 = max(50.0, L1) # Minimum 50mm

    # Uhol divergentného kužeľa (Diffuser Angle - Beta)
    beta_deg = 8.0 # Typicky 6-10 stupňov
    
    # Dĺžka divergentného kužeľa (L2)
    # Zabezpečenie, aby (D4 - D1) > 0 a tan(beta_deg) > 0
    if math.tan(math.radians(beta_deg)) == 0:
        L2 = 100.0 # Default value if angle is zero
    else:
        L2 = (D4 - D1) / (2 * math.tan(math.radians(beta_deg)))
    L2 = max(20.0, L2) # Minimum 20mm

    # Uhol konvergentného kužeľa (Baffle/Convergent Cone Angle - Alpha)
    alpha_deg = 18.0 # Typicky 15-20 stupňov
    
    # Dĺžka konvergentného kužeľa (L4)
    if math.tan(math.radians(alpha_deg)) == 0:
        L4 = 100.0 # Default value if angle is zero
    else:
        L4 = (D4 - D5) / (2 * math.tan(math.radians(alpha_deg)))
    L4 = max(20.0, L4) # Minimum 20mm

    # Nová, lepšia aproximácia celkovej dĺžky rezonančného výfuku (od výfukového portu po začiatok stingera)
    # Vychádza z predpokladu, že rezonancia nastáva v určitom uhle po otvorení výfuku
    effective_exhaust_port_opening_time = vyfuk_duration_deg / (360 * otacky_vykonu_rpm / 60) # in seconds
    L_total_effective = rychlost_zvuku_ms * (0.5 * (60 / otacky_vykonu_rpm) + (vyfuk_duration_deg / 720)) * 1000 # Priblizne, v mm
    L_total_effective = max(200.0, L_total_effective) # Minimalna dlzka

    # L3: Stredná valcová časť
    L_remaining = L_total_effective - L1 - L2 - L4
    L3 = max(10.0, L_remaining) # Aby L3 nebola záporná alebo príliš malá
    
    # Dĺžka koncovej trubky (Stinger/Tailpipe) L5
    L5 = D5 * 11 # Typicky 10-12 násobok priemeru stingera
    L5 = max(50.0, L5) # Minimum 50mm

    return {
        "rychlost_zvuku_ms": round(rychlost_zvuku_ms, 2),
        "D1_vstup_mm": round(D1, 2),
        "L1_header_mm": round(L1, 2),
        "D2_vstup_difuzor_mm": round(D1, 2), # Rovnaký ako D1, pre jasnosť v diagrame L2 začína D2 (rovnaké ako D1)
        "L2_difuzor_mm": round(L2, 2),
        "beta_uhol_deg": round(beta_deg, 2),
        "D3_belly_mm": round(D4, 2), # Koniec difúzora a začiatok belly, pre jasnosť v diagrame L3 začína D3
        "L3_belly_mm": round(L3, 2),
        "D4_vstup_baffle_mm": round(D4, 2), # Rovnaký ako D3_belly_mm
        "L4_baffle_mm": round(L4, 2),
        "alpha_uhol_deg": round(alpha_deg, 2),
        "D5_stinger_mm": round(D5, 2),
        "L5_stinger_mm": round(L5, 2),
        "L_total_effective": round(L_total_effective, 2)
    }

# --- Reset Function ---
def reset_calculator():
    """Resets all session_state variables to their default values."""
    st.session_state.porty = None
    st.session_state.objem_valca = 0
    st.session_state.vrtanie = 66.0
    st.session_state.zdvih = 70.0
    st.session_state.otacky = 9000
    st.session_state.num_main_transfers = 2
    st.session_state.num_aux_transfers = 0
    st.session_state.show_vertical_lines = False
    st.session_state.piston_pos_mm = 0.0
    st.session_state.tvary_portov_actual = {
        "vyfuk": "Obdĺžnik",
        "hlavny": "Obdĺžnik",
        "pomocny": "Obdĺžnik",
        "saci": "Obdĺžnik"
    }
    st.session_state.exhaust_dims = None
    st.session_state.otacky_vykonu = 9500
    st.session_state.teplota_vyfuku = 550
    st.session_state.current_view = "Rozloženie portov (rozvinutý valec)" # Predvolené zobrazenie
    st.rerun() # Refresh the app to apply changes

# --- Streamlit UI ---

# Inicializácia session_state pre všetky premenné, ak ešte neexistujú
# Toto zabezpečí, že hodnoty sa zachovajú aj po interakciách
if 'porty' not in st.session_state:
    reset_calculator() # Zavoláme reset funkciu pre prvú inicializáciu

st.sidebar.title("Ovládanie")
if st.sidebar.button("Reset kalkulačky 🔄", help="Vymaže všetky zadané hodnoty a vráti ich na predvolené."):
    reset_calculator()


st.subheader("🧮 Základné parametre motora")

engine_char = st.selectbox(
    "Vyberte charakteristiku motora pre predvyplnenie parametrov:",
    ["Vlastné nastavenia", "Nízko-otáčkový (práca/krútiaci moment)", "Stredne-otáčkový (univerzálny)", "Vysoko-otáčkový (výkon)"],
    key="engine_char_selector"
)

# Definícia defaultných hodnôt pre inputy na základe engine_char
default_vrtanie = 66.0
default_zdvih = 70.0
default_otacky = 9000
default_otacky_vykonu_char = 9500 
default_teplota_vyfuku_char = 550 

# Check if engine_char_selector has changed before updating values
if 'last_engine_char_selector' not in st.session_state:
    st.session_state['last_engine_char_selector'] = engine_char

if st.session_state['last_engine_char_selector'] != engine_char:
    if engine_char == "Nízko-otáčkový (práca/krútiaci moment)":
        st.session_state.vrtanie = 60.0
        st.session_state.zdvih = 65.0
        st.session_state.otacky = 6000
        st.session_state.otacky_vykonu = 6200
        st.session_state.teplota_vyfuku = 500
    elif engine_char == "Stredne-otáčkový (univerzálny)":
        st.session_state.vrtanie = 66.0
        st.session_state.zdvih = 70.0
        st.session_state.otacky = 9000
        st.session_state.otacky_vykonu = 9500
        st.session_state.teplota_vyfuku = 550
    elif engine_char == "Vysoko-otáčkový (výkon)":
        st.session_state.vrtanie = 70.0
        st.session_state.zdvih = 60.0
        st.session_state.otacky = 12000
        st.session_state.otacky_vykonu = 12500
        st.session_state.teplota_vyfuku = 600
    # Pre "Vlastné nastavenia" sa hodnoty nemenia automaticky, používateľ si ich nastaví sám.

    st.session_state['last_engine_char_selector'] = engine_char
    st.rerun() # Ensure the page updates with new defaults

col1, col2, col3 = st.columns(3)
with col1:
    # Používame st.session_state pre 'value' parameter, aby sa hodnoty zachovali
    vrtanie = st.number_input("Vŕtanie (mm)", min_value=20.0, max_value=150.0, value=st.session_state.vrtanie, help="Priemer valca motora.", key="vrtanie_input")
with col2:
    zdvih = st.number_input("Zdvih (mm)", min_value=20.0, max_value=150.0, value=st.session_state.zdvih, help="Vzdialenosť, ktorú piest prejde od TDC k BDC.", key="zdvih_input")
with col3:
    otacky = st.number_input("Otáčky motora (RPM)", min_value=1000, max_value=20000, value=st.session_state.otacky, help="Maximálne predpokladané otáčky motora za minútu. Výsledky portov sú optimalizované pre tieto otáčky.", key="otacky_input")

st.markdown("---")
st.subheader("🎨 Tvary portov a ich vplyv")

port_tvary = ["Obdĺžnik", "Oblúk", "Lichobežník"]
col4, col5, col6, col7 = st.columns(4)
with col4:
    tvar_vyfuk = st.selectbox("Tvar výfukového portu", port_tvary, index=port_tvary.index(st.session_state.tvary_portov_actual["vyfuk"]), 
                              help="**Obdĺžnik:** Jednoduchý, ale ostré hrany môžu opotrebovávať krúžok. **Oblúk:** Lepšia životnosť krúžku, plynulejší prietok. **Lichobežník:** Usmerňuje prúdenie, vyšší výkon.", key="tvar_vyfuk_select")
with col5:
    tvar_hlavny = st.selectbox("Tvar hlavného preplachovacieho portu", port_tvary, index=port_tvary.index(st.session_state.tvary_portov_actual["hlavny"]), 
                               help="**Obdĺžnik:** Priamy prietok. **Oblúk:** Zlepšuje smerovanie a účinnosť preplachu. **Lichobežník:** Efektívnejšie plnenie valca.", key="tvar_hlavny_select")
with col6:
    tvar_pomocny = st.selectbox("Tvar pomocného preplachovacieho portu", port_tvary, index=port_tvary.index(st.session_state.tvary_portov_actual["pomocny"]), 
                                help="**Obdĺžnik:** Pre dodatočný objem. **Oblúk/Lichobežník:** Jemné ladenie preplachu.", key="tvar_pomocny_select")
with col7:
    tvar_saci = st.selectbox("Tvar sacieho portu", port_tvary, index=port_tvary.index(st.session_state.tvary_portov_actual["saci"]), 
                             help="**Obdĺžnik:** Vysoký prietok. **Oblúk:** Znižuje opotrebenie piesta, hladšie plnenie. **Lichobežník:** Optimalizuje plnenie kľukovej skrine.", key="tvar_saci_select")

st.markdown("---")
st.subheader("🔢 Počet preplachovacích kanálov")
col_kanaly1, col_kanaly2 = st.columns(2)
with col_kanaly1:
    num_main_transfers = st.number_input("Počet hlavných preplachovacích portov", min_value=0, max_value=6, value=st.session_state.num_main_transfers, help="Typicky 2 (loop scavenging) alebo 4 (cross scavenging).", key="num_main_transfers_input")
with col_kanaly2:
    num_aux_transfers = st.number_input("Počet pomocných preplachovacích portov (boost/sub-ports)", min_value=0, max_value=4, value=st.session_state.num_aux_transfers, help="Doplnkové porty na zlepšenie preplachu, často pre vyššie otáčky. Typicky 0, 2 alebo 4.", key="num_aux_transfers_input")

st.markdown("---")
st.subheader("⚙️ Možnosti vizualizácie portov")
col_vis1, col_vis2 = st.columns(2)
with col_vis1:
    show_vertical_lines = st.checkbox("Zobraziť vertikálne referenčné línie na grafe portov", value=st.session_state.show_vertical_lines, help="Pomáha vizuálne prepojiť popisek s portom.", key="show_vertical_lines_checkbox")
with col_vis2:
    piston_pos_mm = st.slider(
        "Simulácia pozície piesta (mm od TDC)", 
        min_value=0.0, 
        max_value=zdvih, 
        value=st.session_state.piston_pos_mm if st.session_state.piston_pos_mm <= zdvih else zdvih, 
        step=1.0, 
        help=f"Posuňte pre zobrazenie aktuálnej výšky piesta a otvorených portov na rozvinutom valci. 0mm = TDC, {zdvih}mm = BDC.",
        key="piston_pos_slider"
    )

calculate_button_clicked = st.button("Vypočítať a zobraziť 🚀", key="calculate_all_button")

if calculate_button_clicked:
    objem = vypocitaj_objem_valca(vrtanie, zdvih)
    
    tvary = {
        "vyfuk": tvar_vyfuk,
        "hlavny": tvar_hlavny,
        "pomocny": tvar_pomocny,
        "saci": tvar_saci
    }
    
    st.session_state.porty = vypocitaj_porty_v2(objem, otacky, zdvih, vrtanie, tvary)
    st.session_state.objem_valca = objem
    st.session_state.vrtanie = vrtanie
    st.session_state.zdvih = zdvih
    st.session_state.otacky = otacky
    st.session_state.num_main_transfers = num_main_transfers
    st.session_state.num_aux_transfers = num_aux_transfers
    st.session_state.show_vertical_lines = show_vertical_lines
    st.session_state.piston_pos_mm = piston_pos_mm
    st.session_state.tvary_portov_actual = tvary 

    if st.session_state.porty and "vyfuk" in st.session_state.porty:
        vyfuk_duration_deg = get_port_timing_details(st.session_state.porty["vyfuk"]["pozicia_od_tdc"], st.session_state.porty["vyfuk"]["vyska"], zdvih)[0]
        vyfuk_sirka_mm = st.session_state.porty["vyfuk"]["sirka"]
        
        st.session_state.exhaust_dims = navrh_vyfuku(st.session_state.otacky_vykonu, st.session_state.teplota_vyfuku, 
                                                     vrtanie, objem, vyfuk_duration_deg, vyfuk_sirka_mm)
    else:
        st.warning("Pre návrh výfuku sú potrebné dáta o výfukovom porte. Skúste najprv vypočítať parametre portov.")
        st.session_state.exhaust_dims = None


# --- Výsledky a Vizualizácie ---
if st.session_state.porty: 
    st.subheader("📊 Vypočítané parametre portov a časovania")

    st.info(f"**Objem valca:** {st.session_state.objem_valca} cm³")

    port_results = []
    for port_key, data in st.session_state.porty.items():
        if data:
            duration, open_point, close_point = get_port_timing_details(data["pozicia_od_tdc"], data["vyska"], st.session_state.zdvih)
            open_time_ms = cas_otvorenia_ms(duration, st.session_state.otacky)
            port_results.append({
                "Typ portu": port_key.capitalize().replace("hlavny", "Hlavný preplach").replace("pomocny", "Pomocný preplach").replace("saci", "Sací").replace("vyfuk", "Výfuk"),
                "Šírka (mm)": round(data["sirka"], 2),
                "Výška (mm)": round(data["vyska"], 2),
                "Poloha od TDC (mm)": round(data["pozicia_od_tdc"], 2),
                "Plocha (mm²)": plocha_portu(data["sirka"], data["vyska"], data["tvar"]),
                "Tvar": data["tvar"],
                "Trvanie (°)": duration,
                "Otvorené pri (°) ATDC": open_point,
                "Zatvorené pri (°) ABDC": close_point,
                "Čas otvorenia (ms)": open_time_ms
            })
    
    st.dataframe(pd.DataFrame(port_results).set_index("Typ portu"))

    st.markdown("---")
    st.subheader("📈 Vizualizácia")

    view_options = ["Rozloženie portov (rozvinutý valec)", "Rez motora (simulácia)", "Návrh výfuku"]
    st.session_state.current_view = st.radio("Vyberte typ vizualizácie:", view_options, key="view_selector", index=view_options.index(st.session_state.current_view))

    if st.session_state.current_view == "Rozloženie portov (rozvinutý valec)":
        st.write("Tu je vizuálne zobrazenie portov, akoby bol valec rozvinutý do roviny. Môžete vidieť šírku, výšku a polohu každého portu, ako aj simulačnú líniu piesta.")
        draw_ports_unrolled(st.session_state.porty, st.session_state.vrtanie, st.session_state.zdvih, 
                            st.session_state.num_main_transfers, st.session_state.num_aux_transfers, 
                            st.session_state.show_vertical_lines, st.session_state.piston_pos_mm)
    elif st.session_state.current_view == "Rez motora (simulácia)":
        st.write("Táto vizualizácia poskytuje jednoduchý pohľad na umiestnenie portov v priereze valca s ohľadom na aktuálnu polohu piesta. Zelené šípky označujú prúdenie.")
        draw_engine_cutaway(st.session_state.porty, st.session_state.vrtanie, st.session_state.zdvih, 
                            st.session_state.piston_pos_mm, st.session_state.num_main_transfers, st.session_state.num_aux_transfers)
    elif st.session_state.current_view == "Návrh výfuku":
        st.subheader("🌪️ Návrh rezonančného výfuku")
        st.write("Rezonančný výfuk je kľúčový pre výkon 2-taktného motora. Tento návrh poskytuje základné rozmery na základe vami zadaných parametrov.")
        
        col_exhaust1, col_exhaust2 = st.columns(2)
        with col_exhaust1:
            st.session_state.otacky_vykonu = st.number_input(
                "Otáčky maximálneho výkonu (RPM)", 
                min_value=1000, max_value=20000, 
                value=st.session_state.otacky_vykonu, 
                help="Otáčky, pre ktoré má byť výfuk ladený (často mierne nad maximálnymi otáčkami motora).", 
                key="otacky_vykonu_input"
            )
        with col_exhaust2:
            st.session_state.teplota_vyfuku = st.number_input(
                "Teplota výfukových plynov (°C)", 
                min_value=300, max_value=800, 
                value=st.session_state.teplota_vyfuku, 
                help="Odhadovaná teplota výfukových plynov. Ovplyvňuje rýchlosť zvuku. Typicky 500-600°C.", 
                key="teplota_vyfuku_input"
            )

        recalculate_exhaust_button = st.button("Prepočítať výfuk", key="recalculate_exhaust_button")
        if recalculate_exhaust_button: 
            if st.session_state.porty and "vyfuk" in st.session_state.porty:
                vyfuk_duration_deg = get_port_timing_details(st.session_state.porty["vyfuk"]["pozicia_od_tdc"], st.session_state.porty["vyfuk"]["vyska"], st.session_state.zdvih)[0]
                vyfuk_sirka_mm = st.session_state.porty["vyfuk"]["sirka"]
                st.session_state.exhaust_dims = navrh_vyfuku(st.session_state.otacky_vykonu, st.session_state.teplota_vyfuku, 
                                                             st.session_state.vrtanie, st.session_state.objem_valca, vyfuk_duration_deg, vyfuk_sirka_mm)
            else:
                st.warning("Najprv musíte vypočítať parametre portov (tlačidlo 'Vypočítať a zobraziť'), aby bolo možné navrhnúť výfuk.")
                st.session_state.exhaust_dims = None

        if st.session_state.exhaust_dims:
            st.info(f"Rýchlosť zvuku vo výfukových plynoch: **{st.session_state.exhaust_dims['rychlost_zvuku_ms']:.2f} m/s**")
            st.info(f"Efektívna celková dĺžka rezonančnej komory (od výfukového portu po začiatok stingera): **{st.session_state.exhaust_dims['L_total_effective']:.1f} mm**")

            # --- Tu sa vkladá váš obrázok a pod ním tabuľka s vypočítanými hodnotami ---
            try:
                st.image("image_7c049c.png", caption="Schéma rezonančného výfuku (Váš obrázok)", use_column_width=True)
            except FileNotFoundError:
                st.warning("Súbor 'image_7c049c.png' sa nenašiel. Uistite sa, že je v rovnakom priečinku ako tento Python skript.")
            # --- Koniec vloženia obrázka ---

            # Tabuľka s vypočítanými hodnotami
            # Prispôsobte názvy stĺpcov a riadkov podľa vášho obrázka
            exhaust_df = pd.DataFrame([
                {"Rozmer": "L1 (mm)", "Hodnota": st.session_state.exhaust_dims["L1_header_mm"]},
                {"Rozmer": "D1 (mm)", "Hodnota": st.session_state.exhaust_dims["D1_vstup_mm"]},
                {"Rozmer": "L2 (mm)", "Hodnota": st.session_state.exhaust_dims["L2_difuzor_mm"]},
                {"Rozmer": "D2 (mm)", "Hodnota": st.session_state.exhaust_dims["D2_vstup_difuzor_mm"]},
                {"Rozmer": "Uhol β (°)", "Hodnota": st.session_state.exhaust_dims["beta_uhol_deg"]},
                {"Rozmer": "L3 (mm)", "Hodnota": st.session_state.exhaust_dims["L3_belly_mm"]},
                {"Rozmer": "D3 (mm)", "Hodnota": st.session_state.exhaust_dims["D3_belly_mm"]},
                {"Rozmer": "L4 (mm)", "Hodnota": st.session_state.exhaust_dims["L4_baffle_mm"]},
                {"Rozmer": "D4 (mm)", "Hodnota": st.session_state.exhaust_dims["D4_vstup_baffle_mm"]},
                {"Rozmer": "Uhol α (°)", "Hodnota": st.session_state.exhaust_dims["alpha_uhol_deg"]},
                {"Rozmer": "L5 (mm)", "Hodnota": st.session_state.exhaust_dims["L5_stinger_mm"]},
                {"Rozmer": "D5 (mm)", "Hodnota": st.session_state.exhaust_dims["D5_stinger_mm"]},
                {"Rozmer": "Celková efektívna dĺžka (mm)", "Hodnota": st.session_state.exhaust_dims["L_total_effective"]}
            ])
            st.dataframe(exhaust_df.set_index("Rozmer"))
            
        else:
            st.info("Zadajte parametre motora a kliknite na 'Vypočítať a zobraziť' pre návrh výfuku.")

st.markdown("---")
st.markdown("Aplikácia je určená len pre orientačné výpočty a vizualizácie. Pre reálne použitie je potrebná podrobná analýza a testovanie.")